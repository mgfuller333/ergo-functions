/* eslint-disable max-len */
const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp(functions.config().firebase);

// // Create and Deploy Your First Cloud Functions
// // https://firebase.google.com/docs/functions/write-firebase-functions
//
// exports.helloWorld = functions.https.onRequest((request, response) => {
//   functions.logger.info("Hello logs!", {structuredData: true});
//   response.send("Hello from Firebase!");
// });

exports.sendNotificationToTopic = functions.firestore
    .document("/AlgorithmData/{documentId}")
    .onWrite((event) => {
      // The topic name can be optionally prefixed with "/topics/".
      const topic = "injuryLog";

      const message = {
        data: {
          score: "Injury",
          time: "Reported",
        },

        notification: {
          title: "[FCM] injury Log:",
          body: "Injury has been reported!",
        },
        topic: topic,
      };

      // Send a message to devices subscribed to the provided topic.
      admin.messaging().send(message)
          .then((response) => {
            // Response is a message ID string.
            console.log("Successfully sent message:", response);
          })
          .catch((error) => {
            console.log("Error sending message:", error);
          });
    });

exports.injuryadded = functions.firestore
    .document("/AlgorithmData/{documentId}")
    .onCreate((snapshot) => {
      console.log(snapshot.data());
      return Promise.resolve();
    });


